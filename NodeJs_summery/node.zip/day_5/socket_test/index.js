const http = require("http");
const socketio = require("socket.io");
const fs = require("fs");
const express = require("express");

const app = express();
const server = http.createServer(app);
server.listen(3000, function() {
  console.log("Server running at http://localhost:3000");
});

app.use("/js", express.static(__dirname + "/resources/js"));

app.get("/", (req, res) => {
  fs.readFile("view/chat.html", "utf-8", (error, data) => {
    res.type("text/html");
    res.send(data);
  } );
});

// Socket 서버 실행하기
const io = socketio.listen(server);

// 브라우저가 접속 했을 때 실행될 이벤트
io.sockets.on("connection", (socket) => {
  console.log(socket.id);

  socket.on("join", (data) => {

    socket.join(data.room);
    io.sockets.in(data.room).emit("receive", {
      "type": "notice",
      "message": data.name + "님이 입장했습니다."
    });

  });

  socket.on("broadcast", (data) => {
    console.log(data);
    io.sockets.in(data.room).emit("receive", data);
  });
});


















//end
