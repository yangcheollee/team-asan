const os = require("os");

const hostName = os.hostname();

console.log(hostName);
