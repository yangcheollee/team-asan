const express = require("express");
const fs = require("fs");
const ejs = require("ejs");

//const client = require("../mysql/mysql_connector");
const Board = require("../mongo/schemas/board");

const router = express.Router();

router.get("/write", function(req, res) {
  fs.readFile("view/write.html", "utf-8", function(error, data) {
    res.type("text/html");
    res.send(data);
  });
});

router.post("/write", function(req, res) {
  // POST 데이터를 얻어옴.
  const subject = req.body.subject;
  const writer = req.body.writer;
  const content = req.body.content;

  const file = req.files.file;
  console.log(file);

  let originalFilename = file.originalFilename;
  let filename = file.path;

  if ( originalFilename != "" ) {
    let fileSplit = filename.split("\\")
    filename = fileSplit[ fileSplit.length-1 ];
  }
  else {
    fs.unlink(filename);
    originalFilename = "";
    filename = "";
  }

  const board = new Board({
    "subject": subject,
    "writer": writer,
    "content": content,
    "originalFilename": originalFilename,
    "filename": filename
  });

  board.save();

  // "/board" 로 이동.
  res.redirect("/board");


});

router.get("/delete/:id", function(req, res) {
  const id = req.params.id;

  Board.findByIdAndRemove(id, function(error, results) {
    // "/board" 페이지로 이동
    res.redirect("/board");
  });

});

router.get("/:id", function(req, res) {

  let id = req.params.id;

  Board.findById(id, function(error, results) {
    fs.readFile("view/detail.html", "utf-8", function(error, data) {
      res.type("text/html");
      res.send(ejs.render(data, results));
    });
  });

});

router.get("/", function(req, res) {

  Board.find( {}, function(error, results) {
    fs.readFile("view/list.html", "utf-8", function(error, data) {
      res.type("text/html");
      res.send(ejs.render(data, {
        "list": results
      }));
    });
  } );

});

exports.router = router;
