const mongoose = require("mongoose");

const client = require("../mongo_connector");
//client();

const boardSchema = mongoose.Schema({
  subject: String,
  content: String,
  writer: String,
  originalFilename: String,
  filename: String
});

module.exports = mongoose.model("board", boardSchema);
