
const http = require("http");
const fs = require("fs");
const url = require("url");

const server = http.createServer( function (request, response) {

  const urlInfo = url.parse(request.url);
  console.log(urlInfo); //URL 정보 출력

  const pathName = urlInfo.pathname;
  console.log(pathName);

  if ( pathName == "/index" ) {
    fs.readFile("helloworld.html", "utf-8", function(error, data) {
      response.writeHead(200, { "Content-Type": "text/html" });
      response.end(data);
    });
  }
  else if ( pathName == "/login" ) {
    if ( request.method == "GET" ) {
      fs.readFile("login.html", "utf-8", function(error, data) {
        response.writeHead(200, { "Content-Type": "text/html" });
        response.end(data);
      });
    }
    else if ( request.method == "POST" ) {
      request.on("data", function(data) {
        console.log(data);
        response.writeHead(200, { "Content-Type": "text/html" });
        response.end(data);
      });
    }
  }
  else {
    response.writeHead(404, {"Content-Type": "text/html"});
    response.end("Page Not Found");
  }

} );

server.listen(3000, function() {
  console.log("Server running at http://localhost:3000");
});
