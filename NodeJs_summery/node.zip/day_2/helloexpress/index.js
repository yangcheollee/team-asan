const express = require("express");
const fs = require("fs");

// Create Server
const app = express();

// Create Middle ware


app.get("/index", function(req, res) {
  fs.readFile("helloworld.html", "utf-8", function(error, data) {
    res.type("text/html");
    res.send(data);
  });
});

app.get("/login", function(req, res) {
  fs.readFile("login.html", "utf-8", function(error, data) {
    res.type("text/html");
    res.send(data);
  });
});

app.post("/login", function(req, res) {

});

app.use(function(req, res) {
  res.type("text/html");
  res.send("Hello, Express");
});

// Run Server
app.listen(3000, function() {
  console.log("Server running at http://localhost:3000");
});
